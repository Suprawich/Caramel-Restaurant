<?php
    include('config.php');
    /* if(isset($_POST['add_to_cart'])){

        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_image = $_POST['product_image'];
        $product_quantity = 1;
     
        $select_cart = mysqli_query($conn, "SELECT * FROM `menu` WHERE name = 'Salad'");
        $fetch_product = mysqli_fetch_assoc('Salad');
        $product_name = $fetch_product['name'];
        $product_price = $fetch_product['price'];
        $product_image = $fetch_product['imgindex'];

        if(mysqli_num_rows($select_cart) > 0){
           $message[] = 'product already added to cart';
        }else{
           $insert_product = mysqli_query($conn, "INSERT INTO `cart`(name, price, image, quantity) VALUES('Salad', '$product_price', '$product_image', '$product_quantity')");
           $message[] = 'product added to cart succesfully';
        }
     
     } */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food</title>
    <link rel="stylesheet" href="food_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="script.js" defer></script>
</head>
<body>
    <header>
        <ul class="front">
            <li><img src="img/Group 6.png" alt=""></li>
            <li><a href="#">Home</a></li>
            <li><a href="test.php">Menu</a></li>
            <li><a href="#">My Order</a></li>
        </ul>
        
        <button class="profile">
            <i class="fas fa-user"></i>
        </button>
        <button class="cart" onclick="show('popup1')">
            <i class="fas fa-cart-shopping"></i> 
            <div class="cartcount"></div>
        </button>
    </header>

    <div class="circle"></div>
    <div class="rect"></div>
    <div class="food"></div>
    <div class="rating">
        <div class="star">
            <i class="fas fa-star" style="background-color: #B99F81; color: #EFCE58;"></i>
        </div>
        <p class="rate">Rating</p>
        <p class="score">4.5</p>
    </div>


    <div class="description">
        <h1>Salad</h1>
        <p class="TH">
            ผักคุณภาพดีคัดสรรค์จากธรรมชาติมาสู่มือคุณ ปราศจากการใช้สารเคมีทุกชนิด
        </p>
        <p class="EN">
            Good quality vegetables selected from nature to your hand. Free from the use of all kinds of chemicals
        </p>
    </div>
    
    <div class="price">
        <div class="priceTH" style="display: inline;">
            <p>ราคา</p>
            <p>125</p>
            <p>บาท</p>
        </div>
        <div class="priceEN">
            <p>Price</p>
            <p>125</p>
            <p>Baht</p>
        </p>
    </div>
   
    <div class="butt">
        <div class="container">
            <div id="decrement-count">
                <input class="decre" type="button" id="down-arrow" value="-" style="background-color: transparent;"/>
            </div>
            <div id="total-count"></div>
            <div id="increment-count">
                <input class="incre" type="button" id="up-arrow" value="+"/>
            </div>
        </div>

        <button class="add-butt">
        <i id="add-butt-cart" class="fas fa-cart-shopping" style="background-color: transparent;"></i>
        Add to cart</button>
    </div>
    
    <div id="popup1" class="overlay">
        <div class="popup">
            <!-- if empty  -->
            <a href="index.php?action=empty">
                <img class="emp-bowl" src="img/bowl.png" alt="" style="background-color: transparent;">
                <p class="emp-word" style="background-color: transparent;">Plate is empty</p>
            </a>
            <!-- if not empty-->
            <p style="position: absolute; width: 100%; text-align: center; padding: 20px; font-weight: 600; text-decoration: underline;">Order</h1>
            <!--<div class="cal-price">
                <p class="name" style="width: 126px; text-align: left;">Salad</p>
                <p class="count" style="width: 39px; text-align: left;">x1</p>
                <p class="count-price" style="width: 69px; text-align: right;">125</p>
                <p class="baht" style="width: 34px; text-align: right;">baht</p>
            </div>
            <div class="total-price">
                <p class="total" style="width: 69px; text-align: right; margin-left: 173px; margin-top: 125px;">125</p>
                <p class="baht" style="width: 34px; text-align: right;">baht</p>
            </div>  -->
            <table class="tbl_cart">
                <tbody>
                    <tr>
                        <th>Name</th>
                        <th>Qt.</th>
                        <th></th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    
    <button id="backgroundOverlay" onclick="hide('popup1')"></div>
    
</body>
</html>