<header class="header">

   <div class="flex">

      <a href="#" class="logo">
         <img src="imgs/Group 6.png" alt="">
      </a>

      <nav class="navbar">
         <a href="#">Home</a></li>
         <a href="test.php">Menu</a></li>
         <a href="#">My Order</a></li>
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

      <a href="cart.php" class="cart">
         <i class="fas fa-cart-shopping"></i> 
         <span style="text-decoration:none;"><?php echo $row_count; ?></span> 
      </a>

      <p class="nav-profile-name" style="font-size: 16px; cursor: pointer; margin-left:30px; margin-right:30px; color:#784A14;">
            <?php 
                session_start();

                if(!$_SESSION['logged_in']){
                  header('Location: error.php');
                  exit();
                }
                extract($_SESSION['userData']);
                
                $avatar_url = "https://cdn.discordapp.com/avatars/$discord_id/$avatar.jpg";
                include_once('functions.php');
                
                $fetchdata = new DB_con();
                $sql = $fetchdata->fetchdata();
                while($row = mysqli_fetch_array($sql)) {
                    if($row['discord_id'] == $discord_id){
                        echo $row['discord_username'];
                    }

            ?>
            <?php 
               }
            ?>
      </p>

   </div>

</header>