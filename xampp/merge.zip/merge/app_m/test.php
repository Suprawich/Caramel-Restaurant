<?php

include('config.php');


if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = 1;

   $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name'");

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product already added to cart';
   }else{
      $insert_product = mysqli_query($conn, "INSERT INTO `cart`(name, price, image, quantity) VALUES('$product_name', '$product_price', '$product_image', '$product_quantity')");
      $message[] = 'product added to cart succesfully';
   }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- custom css file link  -->
    <link rel="stylesheet" href="cartstyle.css">
</head>
<body>
  
<?php include 'header.php'; ?>
  
    <div class="container">
      <div class="sidebar">
        <input type="text" class="sidebar-search" placeholder="Search something...">
        <a href="Fast Food.html" class="sidebar-items">Fast Food</a>
        <a href="#" class="sidebar-items">Vagetalian</a>
        <a href="#" class="sidebar-items">Italian</a>
        <a href="#" class="sidebar-items">Thai</a>
      </div>
      <div class="product">
        <?php
          include('menudb.php');
        ?>
        <form action="" method="post">
          <div class="product-items">
            <img class="product-img" src="imgs/food1.webp" alt="">
            <p style="font-size: 1.2vw;">SANDWICH</p>
            <p stlye="font-size: 1vw;">100 THB</p>
            <?php
              $fetch_product = getFromMenu($pdo2,'03');
            ?>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['imgindex']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
          </div>
        </form>

        <form action="" method="post">      
          <div class="product-items">
            <img class="product-img" src="imgs/food2.png" alt="">
            <p style="font-size: 1.2vw;">Product name</p>
            <p stlye="font-size: 1vw;">500 THB</p>

            <?php
              $fetch_product = getFromMenu($pdo2,'01');
            ?>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['imgindex']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
          </div>
        </form>

        <form action="" method="post"> 
          <div class="product-items">
            <img class="product-img" src="imgs/food3.png" alt="">
            <p style="font-size: 1.2vw;">Product name</p>
            <p stlye="font-size: 1vw;">500 THB</p>

            <?php
              $fetch_product = getFromMenu($pdo2,'05');
            ?>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['imgindex']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
        </div>
        </form>

        <form action="" method="post">
          <div class="product-items">
            <img class="product-img" src="imgs/food4.png" alt="">
            <p style="font-size: 1.2vw;">Product name</p>
            <p stlye="font-size: 1vw;">500 THB</p>

            <?php
              $fetch_product = getFromMenu($pdo2,'03');
            ?>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['imgindex']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
          </div>
        </form>

        <form action="" method="post">
          <div class="product-items">
            <img class="product-img" src="imgs/food5.png" alt="">
            <p style="font-size: 1.2vw;">Product name</p>
            <p stlye="font-size: 1vw;">500 THB</p>

            <?php
              $fetch_product = getFromMenu($pdo2,'03');
            ?>
            
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['imgindex']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
          </div>
        </form>
      </div>
    </div>
  
    <div class="modal" style="display: none;">
      <div class="modal-bg"></div>
      <div class="modal-page">
        <h2>Detail</h2>
        <br>
        <div class="modaldesc-content">
          <img class="modaldesc-img" src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
          <div class="modaldesc-detail">
            <p style="font-size: 1.5vw;">Product name</p>
            <p style="font-size: 1.2vw;">500 THB</p>
            <br>
            <p style="color: #adadad;">Lorem iaudantium harum doloremque alias. Quae, vel ipsum quasi, voluptas, sit optio nemo magni numquam non dicta voluptates porro! Vero eveniet numquam sit aut vel eligendi officiis iste tenetur expedita. Delectus vero quibusdam adipisci in. Esse.</p>
            <br>
            <div class="btn-control">
              <button class="btn">
                Close
              </button>
              <button class="btn btn-buy">
                Add to cart
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div class="modal" style="display: none;">
      <div class="modal-bg"></div>
      <div class="modal-page">
        <h2>My cart</h2>
        <br>
        <div class="cartlist">
          <div class="cartlist-items">
            <div class="cartlist-left">
              <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
              <div class="cartlist-detail">
                <p style="font-size: 1.5vw;">Product name</p>
                <p style="font-size: 1.2vw;">500 THB</p>
              </div>
            </div>
            <div class="cartlist-right">
              <p class="btnc">-</p>
              <p style="margin: 0 20px;">1</p>
              <p class="btnc">+</p>
            </div>
          </div>
          <div class="cartlist-items">
            <div class="cartlist-left">
              <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
              <div class="cartlist-detail">
                <p style="font-size: 1.5vw;">Product name</p>
                <p style="font-size: 1.2vw;">500 THB</p>
              </div>
            </div>
            <div class="cartlist-right">
              <p class="btnc">-</p>
              <p style="margin: 0 20px;">1</p>
              <p class="btnc">+</p>
            </div>
          </div>
          <div class="cartlist-items">
            <div class="cartlist-left">
              <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
              <div class="cartlist-detail">
                <p style="font-size: 1.5vw;">Product name</p>
                <p style="font-size: 1.2vw;">500 THB</p>
              </div>
            </div>
            <div class="cartlist-right">
              <p class="btnc">-</p>
              <p style="margin: 0 20px;">1</p>
              <p class="btnc">+</p>
            </div>
          </div>
          <div class="cartlist-items">
            <div class="cartlist-left">
              <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
              <div class="cartlist-detail">
                <p style="font-size: 1.5vw;">Product name</p>
                <p style="font-size: 1.2vw;">500 THB</p>
              </div>
            </div>
            <div class="cartlist-right">
              <p class="btnc">-</p>
              <p style="margin: 0 20px;">1</p>
              <p class="btnc">+</p>
            </div>
          </div>
          <div class="cartlist-items">
            <div class="cartlist-left">
              <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
              <div class="cartlist-detail">
                <p style="font-size: 1.5vw;">Product name</p>
                <p style="font-size: 1.2vw;">500 THB</p>
              </div>
            </div>
            <div class="cartlist-right">
              <p class="btnc">-</p>
              <p style="margin: 0 20px;">1</p>
              <p class="btnc">+</p>
            </div>
          </div>
          <div class="cartlist-items">
            <div class="cartlist-left">
              <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" alt="">
              <div class="cartlist-detail">
                <p style="font-size: 1.5vw;">Product name</p>
                <p style="font-size: 1.2vw;">500 THB</p>
              </div>
            </div>
            <div class="cartlist-right">
              <p class="btnc">-</p>
              <p style="margin: 0 20px;">1</p>
              <p class="btnc">+</p>
            </div>
          </div>
  
        </div>
        <div class="btn-control">
          <button class="btn">
            Cancel
          </button>
          <button class="btn btn-buy">
            Buy
          </button>
        </div>
      </div>
    </div>
  
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>


    
</body>
</html>