<?php

$conn = mysqli_connect('localhost','root','','new_application_2') or die('connection failed');

?>