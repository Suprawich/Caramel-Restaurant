const incrementCount = document.getElementById("increment-count");
const decrementCount = document.getElementById("decrement-count");

const totalCount = document.getElementById("total-count");

var count = 0;

totalCount.innerHTML = count;

const handleIncrement = () => {
    count++;
    totalCount.innerHTML = count;
  };
  
  // Function to decrement count
const handleDecrement = () => {
    if (count > 0) {
        count--;
    }
    totalCount.innerHTML = count;
};
  
  // Add click event to buttons
incrementCount.addEventListener("click", handleIncrement);
decrementCount.addEventListener("click", handleDecrement);

/* window.onload = function(){
	var popup = document.getElementById('popup1');
    var overlay = document.getElementById('backgroundOverlay');
    var openButton = document.getElementById(id);
    document.onclick = function(e){
        if(e.target.id == 'backgroundOverlay'){
            popup.style.display = 'none';
            overlay.style.display = 'none';
        }
        if(e.target === openButton){
         	popup.style.display = 'block';
            overlay.style.display = 'block';
        }
    };
}; */
//Open Overlay
$ = function(id) {
    return document.getElementById(id);
}
var overlay = document.getElementById('backgroundOverlay');

var show = function(id) {
    $(id).style.display ='block';
    overlay.style.display = 'block';
}
var hide = function(id) {
    $(id).style.display = 'none';
    overlay.style.display = 'none';
}

